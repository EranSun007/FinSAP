const o="_overview_8vvli_1",r="_dashboardGrid_8vvli_5",d="_bottomGrid_8vvli_12",i={overview:o,dashboardGrid:r,bottomGrid:d};export{i as s};
